package com.jam2in.httpapi.response;

public class ArcusLongSuccessResponse {
	
	private Long result=null;
	
	public Long getResult() {
		return result;
	}
	
	public void setResult(Long result) {
		this.result = result;
	}
}