package com.jam2in.httpapi.request;

public class OneRequest {
	String key = null;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
