package com.jam2in.httpapi.request;

import java.util.Collection;

public class OnePluralRequest {
	Collection<String> key = null;

	public Collection<String> getKey() {
		return key;
	}

	public void setKey(Collection<String> key) {
		this.key = key;
	}
}
