package com.jam2in.restapi.Mapper;

public interface ApiMapper {

}
