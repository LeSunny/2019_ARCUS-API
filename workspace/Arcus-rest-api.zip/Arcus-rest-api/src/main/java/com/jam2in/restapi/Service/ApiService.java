package com.jam2in.restapi.Service;

public interface ApiService {

}
