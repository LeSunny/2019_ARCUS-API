package com.jam2in.restapi.Controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestParam;

import net.spy.memcached.ArcusClient;
import net.spy.memcached.ConnectionFactoryBuilder;

import com.jam2in.restapi.config.ArcusConfig;

/**
 * Handles requests for the application home page.
 */
@Controller
@PropertySource("classpath:/arcus.properties")
public class HomeController {
	
	/*private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	**
	 * Simply selects the home view to render by returning its name.
	 */
	/*@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}*/
	
	@Autowired
	private ArcusConfig arcusConfig;

	//RequestMapping URI �κ� ��ġ��
	@RequestMapping(value="/${arcus.address}/${arcus.apiVersion}/${arcus.serviceCode}/set", method=RequestMethod.POST)
	@ResponseBody
	void set(@RequestParam("key")String key, @RequestParam("expireTime")int exp, @RequestParam("obj")Object obj){
		ArcusClient arcusClient;
		arcusClient= arcusConfig.defaultClient();
		
		Future<Boolean> future = null;
		boolean setSuccess = false;
		
		
		future = arcusClient.set(key, exp, obj);
		
		try {
			setSuccess = future.get(700L, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} catch (TimeoutException e) {
			e.printStackTrace();
		}
		
		/*future = arcusClient.set(key, exp, obj);
		
		try {
			setSuccess = future.get(700L, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} catch (TimeoutException e) {
			e.printStackTrace();
		}*/
		
		//service����  set �� �ϰ� �� ����� ���� responsebody�� ����� ����

		
		
	}
	
}
